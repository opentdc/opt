package io.swagger.jersey.listing;

import io.swagger.jaxrs.listing.ApiListingResource;

import javax.ws.rs.Path;

@Path("/")
public class ApiListingResourceJSON
        extends ApiListingResource {
}