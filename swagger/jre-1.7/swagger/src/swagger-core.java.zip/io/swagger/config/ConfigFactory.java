package io.swagger.config;

public class ConfigFactory {

}