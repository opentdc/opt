package io.swagger.models.auth;

public interface SecuritySchemeDefinition {
    String getType();

    void setType(String type);
}