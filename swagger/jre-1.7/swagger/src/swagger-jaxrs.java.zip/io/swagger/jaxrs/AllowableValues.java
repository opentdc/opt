package io.swagger.jaxrs;

interface AllowableValues {
}
