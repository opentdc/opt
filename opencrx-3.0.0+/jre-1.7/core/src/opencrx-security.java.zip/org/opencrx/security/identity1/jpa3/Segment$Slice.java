package org.opencrx.security.identity1.jpa3;

/**
 * <code>Segment$Slice</code> object hold the <code>Segment</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Segment$Slice extends org.opencrx.security.jpa3.Segment$Slice {


  /**
   * Constructor
   */
  public Segment$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Segment$Slice(
    Segment object,
    int index
  ){
    super(object, index);
  }

}

