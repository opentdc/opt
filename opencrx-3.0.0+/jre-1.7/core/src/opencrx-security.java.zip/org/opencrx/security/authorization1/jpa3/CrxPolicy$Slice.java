package org.opencrx.security.authorization1.jpa3;

/**
 * <code>CrxPolicy$Slice</code> object hold the <code>CrxPolicy</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class CrxPolicy$Slice extends org.openmdx.security.authorization1.jpa3.Policy$Slice {


  /**
   * Constructor
   */
  public CrxPolicy$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected CrxPolicy$Slice(
    CrxPolicy object,
    int index
  ){
    super(object, index);
  }

}

