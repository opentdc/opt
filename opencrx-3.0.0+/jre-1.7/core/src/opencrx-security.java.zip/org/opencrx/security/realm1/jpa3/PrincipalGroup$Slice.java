package org.opencrx.security.realm1.jpa3;

/**
 * <code>PrincipalGroup$Slice</code> object hold the <code>PrincipalGroup</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class PrincipalGroup$Slice extends org.openmdx.security.realm1.jpa3.Group$Slice {

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>grantedRole</code>.
   */
  java.lang.String grantedRole;

  public java.lang.String getGrantedRole(
  ){
    return this.grantedRole;
  }

  public void setGrantedRole(
    java.lang.String value
  ){
    this.grantedRole = value;
  }


  /**
   * Constructor
   */
  public PrincipalGroup$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected PrincipalGroup$Slice(
    PrincipalGroup object,
    int index
  ){
    super(object, index);
  }

}

