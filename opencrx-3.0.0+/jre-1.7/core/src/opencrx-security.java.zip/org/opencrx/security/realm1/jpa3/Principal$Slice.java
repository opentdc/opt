package org.opencrx.security.realm1.jpa3;

/**
 * <code>Principal$Slice</code> object hold the <code>Principal</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Principal$Slice extends org.openmdx.security.realm1.jpa3.Principal$Slice {

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>grantedRole</code>.
   */
  java.lang.String grantedRole;

  public java.lang.String getGrantedRole(
  ){
    return this.grantedRole;
  }

  public void setGrantedRole(
    java.lang.String value
  ){
    this.grantedRole = value;
  }


  /**
   * Constructor
   */
  public Principal$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Principal$Slice(
    Principal object,
    int index
  ){
    super(object, index);
  }

}

