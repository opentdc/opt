package org.opencrx.security.authentication1.jpa3;

/**
 * <code>CrxPassword$Slice</code> object hold the <code>CrxPassword</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class CrxPassword$Slice extends org.openmdx.security.authentication1.jpa3.Password$Slice {


  /**
   * Constructor
   */
  public CrxPassword$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected CrxPassword$Slice(
    CrxPassword object,
    int index
  ){
    super(object, index);
  }

}

