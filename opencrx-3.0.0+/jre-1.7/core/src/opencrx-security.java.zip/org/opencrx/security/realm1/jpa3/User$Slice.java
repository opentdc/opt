package org.opencrx.security.realm1.jpa3;

/**
 * <code>User$Slice</code> object hold the <code>User</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class User$Slice extends org.openmdx.security.realm1.jpa3.Group$Slice {


  /**
   * Constructor
   */
  public User$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected User$Slice(
    User object,
    int index
  ){
    super(object, index);
  }

}

