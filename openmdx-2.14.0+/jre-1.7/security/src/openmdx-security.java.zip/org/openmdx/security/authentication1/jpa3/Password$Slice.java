package org.openmdx.security.authentication1.jpa3;

/**
 * <code>Password$Slice</code> object hold the <code>Password</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Password$Slice extends org.openmdx.security.authentication1.jpa3.Credential$Slice {


  /**
   * Constructor
   */
  public Password$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Password$Slice(
    Password object,
    int index
  ){
    super(object, index);
  }

}

