package org.openmdx.security.authentication1.jpa3;

/**
 * <code>Passcode$Slice</code> object hold the <code>Passcode</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Passcode$Slice extends org.openmdx.security.authentication1.jpa3.Credential$Slice {


  /**
   * Constructor
   */
  public Passcode$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Passcode$Slice(
    Passcode object,
    int index
  ){
    super(object, index);
  }

}

