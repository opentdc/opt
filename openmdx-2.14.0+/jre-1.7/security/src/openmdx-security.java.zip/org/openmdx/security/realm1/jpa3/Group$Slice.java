package org.openmdx.security.realm1.jpa3;

/**
 * <code>Group$Slice</code> object hold the <code>Group</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Group$Slice extends org.openmdx.security.realm1.jpa3.Principal$Slice {


  /**
   * Constructor
   */
  public Group$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Group$Slice(
    Group object,
    int index
  ){
    super(object, index);
  }

}

