package org.openmdx.security.authentication1.jpa3;

/**
 * <code>SendPasscode$Slice</code> object hold the <code>SendPasscode</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class SendPasscode$Slice extends org.openmdx.security.authentication1.jpa3.Passcode$Slice {


  /**
   * Constructor
   */
  public SendPasscode$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected SendPasscode$Slice(
    SendPasscode object,
    int index
  ){
    super(object, index);
  }

}

