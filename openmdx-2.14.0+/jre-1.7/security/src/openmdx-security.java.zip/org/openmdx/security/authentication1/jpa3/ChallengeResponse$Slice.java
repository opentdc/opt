package org.openmdx.security.authentication1.jpa3;

/**
 * <code>ChallengeResponse$Slice</code> object hold the <code>ChallengeResponse</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class ChallengeResponse$Slice extends org.openmdx.security.authentication1.jpa3.Credential$Slice {


  /**
   * Constructor
   */
  public ChallengeResponse$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected ChallengeResponse$Slice(
    ChallengeResponse object,
    int index
  ){
    super(object, index);
  }

}

