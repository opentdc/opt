package org.openmdx.generic1.jpa3;

/**
 * <code>BooleanProperty$Slice</code> object hold the <code>BooleanProperty</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class BooleanProperty$Slice extends org.openmdx.generic1.jpa3.Property$Slice {

// ----------------------------------------------------------------------------
// Instance/DeclareValue
// ----------------------------------------------------------------------------

  /**
   * Attribute <code>booleanValue</code>.
   */
  java.lang.Boolean booleanValue;

  public java.lang.Boolean getBooleanValue(
  ){
    return this.booleanValue;
  }

  public void setBooleanValue(
    java.lang.Boolean value
  ){
    this.booleanValue = value;
  }


  /**
   * Constructor
   */
  public BooleanProperty$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected BooleanProperty$Slice(
    BooleanProperty object,
    int index
  ){
    super(object, index);
  }

}

