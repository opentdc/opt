package org.openmdx.generic1.jpa3;

/**
 * <code>IntegerProperty$Slice</code> object hold the <code>IntegerProperty</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class IntegerProperty$Slice extends org.openmdx.generic1.jpa3.Property$Slice {

// ----------------------------------------------------------------------------
// Instance/DeclareValue
// ----------------------------------------------------------------------------

  /**
   * Attribute <code>integerValue</code>.
   */
  java.lang.Integer integerValue;

  public java.lang.Integer getIntegerValue(
  ){
    return this.integerValue;
  }

  public void setIntegerValue(
    java.lang.Integer value
  ){
    this.integerValue = value;
  }


  /**
   * Constructor
   */
  public IntegerProperty$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected IntegerProperty$Slice(
    IntegerProperty object,
    int index
  ){
    super(object, index);
  }

}

