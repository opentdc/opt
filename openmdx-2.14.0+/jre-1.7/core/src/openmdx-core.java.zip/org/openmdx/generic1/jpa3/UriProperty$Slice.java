package org.openmdx.generic1.jpa3;

/**
 * <code>UriProperty$Slice</code> object hold the <code>UriProperty</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class UriProperty$Slice extends org.openmdx.generic1.jpa3.Property$Slice {

// ----------------------------------------------------------------------------
// Instance/DeclareValue
// ----------------------------------------------------------------------------

  /**
   * Attribute <code>uriValue</code>.
   */
  java.net.URI uriValue;

  public java.net.URI getUriValue(
  ){
    return this.uriValue;
  }

  public void setUriValue(
    java.net.URI value
  ){
    this.uriValue = value;
  }


  /**
   * Constructor
   */
  public UriProperty$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected UriProperty$Slice(
    UriProperty object,
    int index
  ){
    super(object, index);
  }

}

