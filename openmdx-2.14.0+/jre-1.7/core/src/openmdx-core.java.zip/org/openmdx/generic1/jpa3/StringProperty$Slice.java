package org.openmdx.generic1.jpa3;

/**
 * <code>StringProperty$Slice</code> object hold the <code>StringProperty</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class StringProperty$Slice extends org.openmdx.generic1.jpa3.Property$Slice {

// ----------------------------------------------------------------------------
// Instance/DeclareValue
// ----------------------------------------------------------------------------

  /**
   * Attribute <code>stringValue</code>.
   */
  java.lang.String stringValue;

  public java.lang.String getStringValue(
  ){
    return this.stringValue;
  }

  public void setStringValue(
    java.lang.String value
  ){
    this.stringValue = value;
  }


  /**
   * Constructor
   */
  public StringProperty$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected StringProperty$Slice(
    StringProperty object,
    int index
  ){
    super(object, index);
  }

}

