package org.openmdx.generic1.jpa3;

/**
 * <code>DecimalProperty$Slice</code> object hold the <code>DecimalProperty</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class DecimalProperty$Slice extends org.openmdx.generic1.jpa3.Property$Slice {

// ----------------------------------------------------------------------------
// Instance/DeclareValue
// ----------------------------------------------------------------------------

  /**
   * Attribute <code>decimalValue</code>.
   */
  java.math.BigDecimal decimalValue;

  public java.math.BigDecimal getDecimalValue(
  ){
    return this.decimalValue;
  }

  public void setDecimalValue(
    java.math.BigDecimal value
  ){
    this.decimalValue = value;
  }


  /**
   * Constructor
   */
  public DecimalProperty$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected DecimalProperty$Slice(
    DecimalProperty object,
    int index
  ){
    super(object, index);
  }

}

