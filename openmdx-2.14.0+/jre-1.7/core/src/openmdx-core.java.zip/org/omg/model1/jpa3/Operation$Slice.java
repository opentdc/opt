package org.omg.model1.jpa3;

/**
 * <code>Operation$Slice</code> object hold the <code>Operation</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Operation$Slice extends org.omg.model1.jpa3.Element$Slice {

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>exception</code>.
   */
  java.lang.String exception;

  public java.lang.String getException(
  ){
    return this.exception;
  }

  public void setException(
    java.lang.String value
  ){
    this.exception = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>content</code>.
   */
  java.lang.String content;

  public java.lang.String getContent(
  ){
    return this.content;
  }

  public void setContent(
    java.lang.String value
  ){
    this.content = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>parameter</code>.
   */
  java.lang.String parameter;

  public java.lang.String getParameter(
  ){
    return this.parameter;
  }

  public void setParameter(
    java.lang.String value
  ){
    this.parameter = value;
  }


  /**
   * Constructor
   */
  public Operation$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Operation$Slice(
    Operation object,
    int index
  ){
    super(object, index);
  }

}

