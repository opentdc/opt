package org.omg.model1.jpa3;

/**
 * <code>Exception$Slice</code> object hold the <code>Exception</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Exception$Slice extends org.omg.model1.jpa3.Element$Slice {

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>content</code>.
   */
  java.lang.String content;

  public java.lang.String getContent(
  ){
    return this.content;
  }

  public void setContent(
    java.lang.String value
  ){
    this.content = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>parameter</code>.
   */
  java.lang.String parameter;

  public java.lang.String getParameter(
  ){
    return this.parameter;
  }

  public void setParameter(
    java.lang.String value
  ){
    this.parameter = value;
  }


  /**
   * Constructor
   */
  public Exception$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Exception$Slice(
    Exception object,
    int index
  ){
    super(object, index);
  }

}

