package org.omg.model1.jpa3;

/**
 * <code>Constraint$Slice</code> object hold the <code>Constraint</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Constraint$Slice extends org.omg.model1.jpa3.Element$Slice {


  /**
   * Constructor
   */
  public Constraint$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Constraint$Slice(
    Constraint object,
    int index
  ){
    super(object, index);
  }

}

