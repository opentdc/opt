package org.omg.model1.jpa3;

/**
 * <code>Tag$Slice</code> object hold the <code>Tag</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Tag$Slice extends org.omg.model1.jpa3.Element$Slice {

// ----------------------------------------------------------------------------
// Instance/DeclareValue
// ----------------------------------------------------------------------------

  /**
   * Attribute <code>tagValue</code>.
   */
  java.lang.String tagValue;

  public java.lang.String getTagValue(
  ){
    return this.tagValue;
  }

  public void setTagValue(
    java.lang.String value
  ){
    this.tagValue = value;
  }


  /**
   * Constructor
   */
  public Tag$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Tag$Slice(
    Tag object,
    int index
  ){
    super(object, index);
  }

}

