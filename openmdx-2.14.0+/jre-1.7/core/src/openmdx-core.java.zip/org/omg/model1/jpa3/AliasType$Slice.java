package org.omg.model1.jpa3;

/**
 * <code>AliasType$Slice</code> object hold the <code>AliasType</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class AliasType$Slice extends org.omg.model1.jpa3.Element$Slice {

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>attribute</code>.
   */
  java.lang.String attribute;

  public java.lang.String getAttribute(
  ){
    return this.attribute;
  }

  public void setAttribute(
    java.lang.String value
  ){
    this.attribute = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>supertype</code>.
   */
  java.lang.String supertype;

  public java.lang.String getSupertype(
  ){
    return this.supertype;
  }

  public void setSupertype(
    java.lang.String value
  ){
    this.supertype = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>operation</code>.
   */
  java.lang.String operation;

  public java.lang.String getOperation(
  ){
    return this.operation;
  }

  public void setOperation(
    java.lang.String value
  ){
    this.operation = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>feature</code>.
   */
  java.lang.String feature;

  public java.lang.String getFeature(
  ){
    return this.feature;
  }

  public void setFeature(
    java.lang.String value
  ){
    this.feature = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>allSupertype</code>.
   */
  java.lang.String allSupertype;

  public java.lang.String getAllSupertype(
  ){
    return this.allSupertype;
  }

  public void setAllSupertype(
    java.lang.String value
  ){
    this.allSupertype = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>allSubtype</code>.
   */
  java.lang.String allSubtype;

  public java.lang.String getAllSubtype(
  ){
    return this.allSubtype;
  }

  public void setAllSubtype(
    java.lang.String value
  ){
    this.allSubtype = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>reference</code>.
   */
  java.lang.String reference;

  public java.lang.String getReference(
  ){
    return this.reference;
  }

  public void setReference(
    java.lang.String value
  ){
    this.reference = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>content</code>.
   */
  java.lang.String content;

  public java.lang.String getContent(
  ){
    return this.content;
  }

  public void setContent(
    java.lang.String value
  ){
    this.content = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>field</code>.
   */
  java.lang.String field;

  public java.lang.String getField(
  ){
    return this.field;
  }

  public void setField(
    java.lang.String value
  ){
    this.field = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>subtype</code>.
   */
  java.lang.String subtype;

  public java.lang.String getSubtype(
  ){
    return this.subtype;
  }

  public void setSubtype(
    java.lang.String value
  ){
    this.subtype = value;
  }


  /**
   * Constructor
   */
  public AliasType$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected AliasType$Slice(
    AliasType object,
    int index
  ){
    super(object, index);
  }

}

