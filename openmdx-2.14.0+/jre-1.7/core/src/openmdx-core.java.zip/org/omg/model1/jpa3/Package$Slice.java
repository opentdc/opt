package org.omg.model1.jpa3;

/**
 * <code>Package$Slice</code> object hold the <code>Package</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Package$Slice extends org.omg.model1.jpa3.Element$Slice {

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>allSubtype</code>.
   */
  java.lang.String allSubtype;

  public java.lang.String getAllSubtype(
  ){
    return this.allSubtype;
  }

  public void setAllSubtype(
    java.lang.String value
  ){
    this.allSubtype = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>supertype</code>.
   */
  java.lang.String supertype;

  public java.lang.String getSupertype(
  ){
    return this.supertype;
  }

  public void setSupertype(
    java.lang.String value
  ){
    this.supertype = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>content</code>.
   */
  java.lang.String content;

  public java.lang.String getContent(
  ){
    return this.content;
  }

  public void setContent(
    java.lang.String value
  ){
    this.content = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>subtype</code>.
   */
  java.lang.String subtype;

  public java.lang.String getSubtype(
  ){
    return this.subtype;
  }

  public void setSubtype(
    java.lang.String value
  ){
    this.subtype = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>feature</code>.
   */
  java.lang.String feature;

  public java.lang.String getFeature(
  ){
    return this.feature;
  }

  public void setFeature(
    java.lang.String value
  ){
    this.feature = value;
  }

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>allSupertype</code>.
   */
  java.lang.String allSupertype;

  public java.lang.String getAllSupertype(
  ){
    return this.allSupertype;
  }

  public void setAllSupertype(
    java.lang.String value
  ){
    this.allSupertype = value;
  }


  /**
   * Constructor
   */
  public Package$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Package$Slice(
    Package object,
    int index
  ){
    super(object, index);
  }

}

