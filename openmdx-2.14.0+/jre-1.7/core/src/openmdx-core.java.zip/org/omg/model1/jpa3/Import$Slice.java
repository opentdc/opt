package org.omg.model1.jpa3;

/**
 * <code>Import$Slice</code> object hold the <code>Import</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Import$Slice extends org.omg.model1.jpa3.Element$Slice {


  /**
   * Constructor
   */
  public Import$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Import$Slice(
    Import object,
    int index
  ){
    super(object, index);
  }

}

