package org.omg.model1.jpa3;

/**
 * <code>AssociationEnd$Slice</code> object hold the <code>AssociationEnd</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class AssociationEnd$Slice extends org.omg.model1.jpa3.Element$Slice {

// ----------------------------------------------------------------------------
// Instance/ReferenceDeclaration
// ----------------------------------------------------------------------------
  /**
   * Instance referenced by <code>qualifierType</code>.
   */
  java.lang.String qualifierType;

  public java.lang.String getQualifierType(
  ){
    return this.qualifierType;
  }

  public void setQualifierType(
    java.lang.String value
  ){
    this.qualifierType = value;
  }

// ----------------------------------------------------------------------------
// Instance/DeclareValue
// ----------------------------------------------------------------------------

  /**
   * Attribute <code>qualifierName</code>.
   */
  java.lang.String qualifierName;

  public java.lang.String getQualifierName(
  ){
    return this.qualifierName;
  }

  public void setQualifierName(
    java.lang.String value
  ){
    this.qualifierName = value;
  }


  /**
   * Constructor
   */
  public AssociationEnd$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected AssociationEnd$Slice(
    AssociationEnd object,
    int index
  ){
    super(object, index);
  }

}

