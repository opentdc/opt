package org.omg.model1.jpa3;

/**
 * <code>Constant$Slice</code> object hold the <code>Constant</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Constant$Slice extends org.omg.model1.jpa3.Element$Slice {


  /**
   * Constructor
   */
  public Constant$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Constant$Slice(
    Constant object,
    int index
  ){
    super(object, index);
  }

}

