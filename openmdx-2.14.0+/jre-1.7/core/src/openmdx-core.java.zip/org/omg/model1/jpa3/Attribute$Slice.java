package org.omg.model1.jpa3;

/**
 * <code>Attribute$Slice</code> object hold the <code>Attribute</code>'s multivalued attributes
 */
@SuppressWarnings("serial")
public class Attribute$Slice extends org.omg.model1.jpa3.Element$Slice {


  /**
   * Constructor
   */
  public Attribute$Slice(
  ){
    // Implements Serializable
  }

  /**
   * Constructor
   */
  protected Attribute$Slice(
    Attribute object,
    int index
  ){
    super(object, index);
  }

}

