package com.jayway.jsonpath.internal;

public class EvaluationAbortException extends RuntimeException {
}
